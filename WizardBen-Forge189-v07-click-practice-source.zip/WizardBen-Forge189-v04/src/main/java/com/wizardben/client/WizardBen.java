package com.wizardben.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;

@Mod(modid = WizardBen.MODID, name = WizardBen.NAME, version = WizardBen.VERSION, clientSideOnly = true)
public class WizardBen {
    public static final String MODID = "wizardben";
    public static final String NAME = "Wizard Ben";
    public static final String VERSION = "0.7.0";
    private static final Minecraft MC = Minecraft.getMinecraft();

    private KeyBinding menuKey;
    private KeyBinding trainerKey;
    private boolean hud = true, keys = true, cpsCounter = true, coordinates = false;
    private boolean trainerEnabled = false;
    private int targetCps = 12;
    private boolean lastLeft = false, lastRight = false;
    private final Deque<Long> clicks = new ArrayDeque<Long>();
    private int cps = 0;
    private long trainerStartedAt = 0L;
    private boolean trainerActivePhase = false;
    private int trainerBeat = 0;
    private int trainerClicksThisPhase = 0;
    private boolean previousTrainerActivePhase = false;
    // KillAura configuration panel is a UI preview only; no targeting or attacks are performed.
    private boolean killAuraUiEnabled = false;
    private int killAuraCps = 12;
    private double killAuraRange = 3.0;
    private int killAuraTargetMode = 0;
    private int killAuraRotationMode = 0;
    // Combat entries below are UI-only placeholders; they do not alter combat or send input.
    private final String[] combatModules = {"AimAssist", "AutoClicker", "Reach", "Velocity", "HitSelect", "W-Tap", "Backtrack", "AutoBlock"};
    private final boolean[] combatUiStates = new boolean[8];

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        menuKey = new KeyBinding("Wizard Ben: Open Menu", Keyboard.KEY_RSHIFT, "Wizard Ben");
        trainerKey = new KeyBinding("Wizard Ben: Toggle Rhythm Trainer", Keyboard.KEY_F6, "Wizard Ben");
        ClientRegistry.registerKeyBinding(menuKey);
        ClientRegistry.registerKeyBinding(trainerKey);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (menuKey != null && menuKey.isPressed()) MC.displayGuiScreen(new WizardMenu(this));
        if (trainerKey != null && trainerKey.isPressed()) toggleTrainer();
        if (MC.thePlayer == null) return;

        long now = System.currentTimeMillis();
        if (trainerEnabled) updateTrainer(now);
        boolean left = Mouse.isButtonDown(0), right = Mouse.isButtonDown(1);
        boolean newClick = (left && !lastLeft) || (right && !lastRight);
        if (newClick) {
            clicks.addLast(now);
            if (trainerEnabled && trainerActivePhase) trainerClicksThisPhase++;
        }
        lastLeft = left; lastRight = right;
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000L) clicks.removeFirst();
        cps = clicks.size();
    }

    private void toggleTrainer() {
        trainerEnabled = !trainerEnabled;
        trainerStartedAt = System.currentTimeMillis();
        trainerActivePhase = true;
        previousTrainerActivePhase = false;
        trainerClicksThisPhase = 0;
        trainerBeat = 0;
    }

    // Manual click-rhythm practice only: it measures your physical clicks and never generates mouse input or attacks entities.
    private void updateTrainer(long now) {
        long cycle = (now - trainerStartedAt) % 1500L;
        trainerActivePhase = cycle < 1000L; // 1.0 s practice phase, 0.5 s rest phase
        if (trainerActivePhase != previousTrainerActivePhase) {
            trainerClicksThisPhase = 0;
            previousTrainerActivePhase = trainerActivePhase;
        }
        if (trainerActivePhase) {
            trainerBeat = Math.min(targetCps, (int)((cycle * targetCps) / 1000L) + 1);
        } else {
            trainerBeat = 0;
        }
    }

    @SubscribeEvent
    public void onHud(RenderGameOverlayEvent.Text event) {
        if (MC.thePlayer == null || MC.theWorld == null || !hud) return;
        int x = 7, y = 7;
        MC.fontRendererObj.drawStringWithShadow("WIZARD BEN", x, y, 0xCC88FF);
        MC.fontRendererObj.drawStringWithShadow("FPS: " + Minecraft.getDebugFPS(), x, y + 12, 0xFFFFFF);
        if (cpsCounter) MC.fontRendererObj.drawStringWithShadow("CPS: " + cps, x, y + 24, 0xFFFFFF);
        if (coordinates) {
            MC.fontRendererObj.drawStringWithShadow(String.format("XYZ: %.1f / %.1f / %.1f", MC.thePlayer.posX, MC.thePlayer.posY, MC.thePlayer.posZ), x, y + 36, 0xFFFFFF);
        }
        if (trainerEnabled) {
            String state = trainerActivePhase ? "PRACTICE" : "REST";
            String beat = trainerActivePhase ? ("BEAT: " + trainerBeat + "/" + targetCps) : "PAUSE: 0.5s";
            MC.fontRendererObj.drawStringWithShadow("RHYTHM TRAINER: " + state, x, y + 48, trainerActivePhase ? 0x55FF88 : 0xFFCC55);
            MC.fontRendererObj.drawStringWithShadow("TARGET: " + targetCps + " CPS  " + beat, x, y + 60, 0xFFFFFF);
            MC.fontRendererObj.drawStringWithShadow("YOUR CLICKS THIS ROUND: " + trainerClicksThisPhase, x, y + 72, 0xFFFFFF);
        }
        if (keys) drawKeys();
    }

    private void drawKeys() {
        int x = 7, y = MC.displayHeight / 2 / MC.gameSettings.guiScale - 8;
        drawKey(x, y, "W", Keyboard.isKeyDown(Keyboard.KEY_W));
        drawKey(x, y + 18, "A", Keyboard.isKeyDown(Keyboard.KEY_A));
        drawKey(x + 18, y + 18, "S", Keyboard.isKeyDown(Keyboard.KEY_S));
        drawKey(x + 36, y + 18, "D", Keyboard.isKeyDown(Keyboard.KEY_D));
        drawKey(x + 54, y + 18, "L", Mouse.isButtonDown(0));
        drawKey(x + 72, y + 18, "R", Mouse.isButtonDown(1));
    }
    private void drawKey(int x, int y, String label, boolean down) {
        int c = down ? 0xDD7744CC : 0xAA20202A;
        net.minecraft.client.gui.Gui.drawRect(x, y, x + 17, y + 16, c);
        MC.fontRendererObj.drawStringWithShadow(label, x + 5, y + 4, 0xFFFFFF);
    }

    private static class WizardMenu extends GuiScreen {
        private final WizardBen mod;
        WizardMenu(WizardBen mod) { this.mod = mod; }
        @Override public void initGui() {
            buttonList.clear();
            int left = width / 2 - 150;
            int top = height / 2 - 105;
            buttonList.add(new GuiButton(1, left, top, 145, 20, label("HUD", mod.hud)));
            buttonList.add(new GuiButton(2, left + 155, top, 145, 20, label("Keystrokes", mod.keys)));
            buttonList.add(new GuiButton(3, left, top + 23, 145, 20, label("CPS Counter", mod.cpsCounter)));
            buttonList.add(new GuiButton(4, left + 155, top + 23, 145, 20, label("Coordinates", mod.coordinates)));
            buttonList.add(new GuiButton(5, left, top + 46, 145, 20, label("Rhythm Trainer", mod.trainerEnabled)));
            buttonList.add(new GuiButton(6, left + 155, top + 46, 145, 20, "Target CPS: " + mod.targetCps));
            buttonList.add(new GuiButton(20, left, top + 75, 145, 20,
                    "KillAura [" + (mod.killAuraUiEnabled ? "ON" : "OFF") + "] >"));
            String[] names = {"AimAssist", "AutoClicker", "Reach", "Velocity", "HitSelect", "W-Tap", "Backtrack", "AutoBlock"};
            for (int i = 0; i < names.length; i++) {
                int col = i % 2, row = i / 2;
                buttonList.add(new GuiButton(21 + i, left + col * 155, top + 98 + row * 23, 145, 20,
                        names[i] + " [UI " + (mod.combatUiStates[i] ? "ON" : "OFF") + "]"));
            }
            buttonList.add(new GuiButton(8, width / 2 - 45, top + 190, 90, 20, "Close"));
        }
        private String label(String name, boolean on) { return name + ": " + (on ? "ON" : "OFF"); }
        @Override protected void actionPerformed(GuiButton b) throws IOException {
            if (b.id == 1) mod.hud = !mod.hud;
            else if (b.id == 2) mod.keys = !mod.keys;
            else if (b.id == 3) mod.cpsCounter = !mod.cpsCounter;
            else if (b.id == 4) mod.coordinates = !mod.coordinates;
            else if (b.id == 5) mod.toggleTrainer();
            else if (b.id == 6) mod.targetCps = (mod.targetCps == 12 ? 17 : 12);
            else if (b.id == 20) { MC.displayGuiScreen(new KillAuraSettingsMenu(mod)); return; }
            else if (b.id >= 21 && b.id < 29) mod.combatUiStates[b.id - 21] = !mod.combatUiStates[b.id - 21];
            else if (b.id == 8) { MC.displayGuiScreen(null); return; }
            initGui();
        }
        @Override public void drawScreen(int mouseX, int mouseY, float partialTicks) {
            drawDefaultBackground();
            int top = height / 2 - 105;
            drawCenteredString(fontRendererObj, "WIZARD BEN v0.7  /  MODULES", width / 2, top - 18, 0xCC88FF);
            drawCenteredString(fontRendererObj, "Combat entries are interface previews only", width / 2, top + 184, 0xFFCC55);
            super.drawScreen(mouseX, mouseY, partialTicks);
        }
        @Override public boolean doesGuiPauseGame() { return false; }
    }
    private static class KillAuraSettingsMenu extends GuiScreen {
        private final WizardBen mod;
        KillAuraSettingsMenu(WizardBen mod) { this.mod = mod; }

        @Override public void initGui() {
            buttonList.clear();
            int left = width / 2 - 100;
            int top = height / 2 - 85;
            buttonList.add(new GuiButton(101, left, top, 200, 20,
                    "KillAura UI: " + (mod.killAuraUiEnabled ? "ON" : "OFF")));
            buttonList.add(new GuiButton(102, left, top + 24, 200, 20,
                    "CPS Preview: " + mod.killAuraCps));
            buttonList.add(new GuiButton(103, left, top + 48, 200, 20,
                    String.format("Range Display: %.1f", mod.killAuraRange)));
            buttonList.add(new GuiButton(104, left, top + 72, 200, 20,
                    "Target Mode: " + targetName(mod.killAuraTargetMode)));
            buttonList.add(new GuiButton(105, left, top + 96, 200, 20,
                    "Rotation Mode: " + rotationName(mod.killAuraRotationMode)));
            buttonList.add(new GuiButton(106, left, top + 130, 200, 20, "Back"));
        }
        private String targetName(int value) {
            return value == 0 ? "Single (preview)" : value == 1 ? "Switch (preview)" : "Priority (preview)";
        }
        private String rotationName(int value) {
            return value == 0 ? "None (UI only)" : value == 1 ? "Smooth (UI only)" : "Snap (UI only)";
        }
        @Override protected void actionPerformed(GuiButton b) throws IOException {
            if (b.id == 101) mod.killAuraUiEnabled = !mod.killAuraUiEnabled;
            else if (b.id == 102) mod.killAuraCps = mod.killAuraCps == 12 ? 17 : 12;
            else if (b.id == 103) mod.killAuraRange = mod.killAuraRange >= 4.5 ? 2.5 : mod.killAuraRange + 0.5;
            else if (b.id == 104) mod.killAuraTargetMode = (mod.killAuraTargetMode + 1) % 3;
            else if (b.id == 105) mod.killAuraRotationMode = (mod.killAuraRotationMode + 1) % 3;
            else if (b.id == 106) { MC.displayGuiScreen(new WizardMenu(mod)); return; }
            initGui();
        }
        @Override public void drawScreen(int mouseX, int mouseY, float partialTicks) {
            drawDefaultBackground();
            int top = height / 2 - 105;
            drawCenteredString(fontRendererObj, "KILLAURA SETTINGS  /  UI PREVIEW", width / 2, top, 0xCC88FF);
            drawCenteredString(fontRendererObj, "These values are display settings only; no attacks are sent.", width / 2, top + 162, 0xFFCC55);
            super.drawScreen(mouseX, mouseY, partialTicks);
        }
        @Override public boolean doesGuiPauseGame() { return false; }
    }

}

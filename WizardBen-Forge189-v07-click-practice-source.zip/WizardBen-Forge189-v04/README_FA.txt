Wizard Ben v0.6 - Minecraft 1.8.9 Forge

امکانات:
- منوی اصلی با Right Shift
- HUD، FPS، CPS واقعی، Keystrokes و مختصات
- Rhythm Trainer با F6 و انتخاب 12/17 CPS (فقط نمایش ریتم؛ هیچ ورودی خودکاری تولید نمی‌کند)
- منوی Combat شامل KillAura UI و تنظیمات نمایشی آن
- تنظیمات نمایشی KillAura: ON/OFF، CPS Preview (12/17)، Range Display، Target Mode و Rotation Mode
- سایر ورودی‌ها: AimAssist، AutoClicker، Reach، Velocity، HitSelect، W-Tap، Backtrack و AutoBlock

مهم:
KillAura در این نسخه فقط رابط و تنظیمات نمایشی دارد؛ هیچ هدف‌گیری، چرخش خودکار، حمله یا کلیک خودکاری انجام نمی‌دهد. سایر ماژول‌های Combat نیز رابط نمایشی هستند.

این فایل سورس پروژه است، نه JAR آماده. برای ساخت به Java 8 و ForgeGradle 2.1 نیاز است. ساخت و اجرای پروژه روی PojavLauncher هنوز تست نشده است.
